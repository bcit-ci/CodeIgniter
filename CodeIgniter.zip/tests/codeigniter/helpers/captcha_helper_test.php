<?php

class Captcha_helper_test extends CI_TestCase {

	public function test_create_captcha()
	{
		$this->markTestSkipped("Can't test");
	}

}